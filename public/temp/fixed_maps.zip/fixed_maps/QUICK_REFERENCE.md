# QUICK REFERENCE CARD - SVG Venue Maps

## 📁 What's in This Folder?

```
fixed_maps/
├── README_COMPLETE_GUIDE.md    ← START HERE! Complete A-Z guide
├── 124 venue SVG files (.txt)  ← Your map files
└── fix_log.json                ← What was fixed
```

## 🚀 Quick Start (3 Steps)

### 1. Load SVG File
```javascript
fetch('/venue-maps/Madison_Square_Garden.txt')
  .then(r => r.text())
  .then(data => {
    const svg = data.match(/<svg[^>]*>[\s\S]*<\/svg>/)[0];
    document.getElementById('map').innerHTML = svg;
    initializeMap();
  });
```

### 2. Make Sections Clickable
```javascript
function initializeMap() {
  document.querySelectorAll('.interactive-section').forEach(section => {
    section.addEventListener('click', () => {
      const id = section.getAttribute('data-section-id');
      addToCart(id);
    });
  });
}
```

### 3. Add to Cart
```javascript
function addToCart(sectionId) {
  const path = document.querySelector(`[data-section-id="${sectionId}"] .section-path`);
  path.style.fill = 'rgb(20, 116, 225)'; // Selected color
  console.log(`Added section ${sectionId} to cart`);
}
```

## 🔑 Critical Attributes

Every section MUST have:

```xml
<g class="interactive-section"           ← For JavaScript
   data-section-id="101">                ← For cart/filter
  
  <path class="section-path"             ← The clickable area
        data-id="2742140"                ← Backend ID
        data-default-color="rgb(204,204,204)"  ← Reset color
        d="M 100,500 L 400,500...">      ← The shape
  </path>
  
  <text class="section-label"            ← Section name
        x="250" y="610">
    101
  </text>
</g>
```

## 🎨 Color Codes

```javascript
const COLORS = {
  default:  'rgb(204, 204, 204)',  // Gray
  premium:  'rgb(62, 149, 237)',   // Blue
  ga:       'rgb(68, 185, 108)',   // Green
  vip:      'rgb(222, 145, 43)',   // Orange
  selected: 'rgb(20, 116, 225)',   // Dark blue
  hover:    'rgb(142, 190, 245)'   // Light blue
};
```

## 🔍 Search/Filter

```javascript
function filterSections(searchTerm) {
  document.querySelectorAll('.interactive-section').forEach(section => {
    const id = section.getAttribute('data-section-id').toLowerCase();
    const matches = id.includes(searchTerm.toLowerCase());
    section.style.opacity = matches ? '1' : '0.2';
  });
}
```

## ✅ Validation Script

Paste in browser console:

```javascript
function validateMap() {
  const sections = document.querySelectorAll('.interactive-section');
  let valid = true;
  
  sections.forEach(s => {
    if (!s.getAttribute('data-section-id')) {
      console.error('Missing data-section-id:', s);
      valid = false;
    }
    const path = s.querySelector('.section-path');
    if (!path || !path.getAttribute('data-id')) {
      console.error('Missing path or data-id:', s);
      valid = false;
    }
  });
  
  console.log(valid ? '✅ Valid!' : '❌ Has issues');
  return valid;
}
validateMap();
```

## 🐛 Common Issues

| Problem | Solution |
|---------|----------|
| Sections not clickable | Call `initializeMap()` after loading SVG |
| Wrong section selected | Check for duplicate `data-section-id` |
| Labels missing | Use files from `fixed_maps/` (already fixed!) |
| Colors wrong | Use RGB format: `rgb(r, g, b)` |
| Search not working | Convert to lowercase for comparison |

## 📚 Full Documentation

See **README_COMPLETE_GUIDE.md** for:
- Complete code examples
- Step-by-step tutorials
- CSS styling
- Cart implementation
- Hover effects
- And much more!

## 📊 Stats

- ✅ 124 venue maps
- ✅ 6,817 issues fixed
- ✅ All sections have labels
- ✅ All IDs are unique
- ✅ All colors are valid
- ✅ Ready to use!

---

**Need help? Check README_COMPLETE_GUIDE.md for detailed instructions!**
