# COMPLETE A-TO-Z GUIDE: SVG Venue Maps Implementation

## 📋 Table of Contents
1. [Overview](#overview)
2. [File Structure](#file-structure)
3. [SVG Code Anatomy](#svg-code-anatomy)
4. [Required Attributes](#required-attributes)
5. [JavaScript Implementation](#javascript-implementation)
6. [CSS Styling](#css-styling)
7. [Cart Functionality](#cart-functionality)
8. [Search/Filter Implementation](#searchfilter-implementation)
9. [Color System](#color-system)
10. [Testing & Validation](#testing--validation)
11. [Common Issues & Solutions](#common-issues--solutions)
12. [Complete Working Example](#complete-working-example)

---

## Overview

### What Are These Files?
These are **124 SVG (Scalable Vector Graphics) venue seating maps** for different event venues. Each file contains:
- Vector paths defining seating sections
- Interactive elements for clicking
- Labels showing section names
- Metadata for cart and filtering functionality

### What Can Users Do?
1. **Click sections** to add them to a shopping cart
2. **Search/filter** to find specific sections
3. **Hover** over sections to see details
4. **View pricing** for each section

---

## File Structure

### Directory Layout
```
fixed_maps/
├── README_COMPLETE_GUIDE.md        # This file
├── 713_Music_Hall.txt              # Venue 1
├── Allstate_Arena.txt              # Venue 2
├── ... (122 more venue files)
├── Xfinity_Mobile_Arena.txt        # Venue 124
└── fix_log.json                    # Log of fixes applied
```

### File Format
Each `.txt` file contains:
```
Venue: [Venue Name]
URL: [Source URL]
Title: [Event Title]

================================================================================
SVG MAP CODE:
================================================================================

<svg>...</svg>
```

---

## SVG Code Anatomy

### Complete SVG Structure

Every SVG file follows this exact structure:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" 
     xmlns:xlink="http://www.w3.org/1999/xlink"
     viewBox="0 0 3000 2200"
     width="100%" 
     height="100%">
  
  <!-- 1. DEFINITIONS (Styles, Gradients, Patterns) -->
  <defs>
    <style type="text/css">
      .interactive-section { cursor: pointer; }
      .section-path { transition: fill 0.3s ease; }
      .section-label { 
        font-family: Arial, sans-serif;
        pointer-events: none;
      }
    </style>
  </defs>
  
  <!-- 2. PARENT GROUP (Main Container) -->
  <g id="parent-group" 
     class="interactive-section" 
     data-section-id="parent">
    
    <!-- 3. STATIC ELEMENTS (Non-interactive) -->
    <g id="static-elements">
      <!-- Stage -->
      <rect x="1000" y="100" width="1000" height="200" 
            fill="#666" stroke="#000"/>
      <text x="1500" y="220" font-size="60" 
            text-anchor="middle">STAGE</text>
      
      <!-- Row labels, aisles, etc. -->
    </g>
    
    <!-- 4. INTERACTIVE SECTIONS (The Important Part!) -->
    <g id="sections">
      
      <!-- SECTION 1 -->
      <g class="interactive-section" 
         id="101-group" 
         data-section-id="101">
        
        <!-- The clickable area -->
        <path class="section-path"
              id="101-section"
              d="M 100,500 L 400,500 L 400,700 L 100,700 Z"
              data-default-color="rgb(204, 204, 204)"
              data-id="2742140"
              style="fill: rgb(204, 204, 204); 
                     stroke: rgb(102, 102, 102); 
                     stroke-width: 1px;">
        </path>
        
        <!-- The label -->
        <text class="section-label 101-label"
              id="101-label"
              x="250"
              y="610"
              font-size="24px"
              text-anchor="middle"
              fill="#000000">
          101
        </text>
      </g>
      
      <!-- SECTION 2 -->
      <g class="interactive-section" 
         id="102-group" 
         data-section-id="102">
        <path class="section-path"
              id="102-section"
              d="M 450,500 L 750,500 L 750,700 L 450,700 Z"
              data-default-color="rgb(204, 204, 204)"
              data-id="2742141"
              style="fill: rgb(204, 204, 204); 
                     stroke: rgb(102, 102, 102); 
                     stroke-width: 1px;">
        </path>
        <text class="section-label 102-label"
              id="102-label"
              x="600"
              y="610"
              font-size="24px"
              text-anchor="middle"
              fill="#000000">
          102
        </text>
      </g>
      
      <!-- ... more sections ... -->
      
    </g>
  </g>
</svg>
```

### Breaking Down Each Part

#### 1. SVG Root Element
```xml
<svg xmlns="http://www.w3.org/2000/svg" 
     viewBox="0 0 3000 2200">
```
- **`xmlns`**: Defines this as an SVG document
- **`viewBox`**: Defines the coordinate system (x, y, width, height)
  - Example: `"0 0 3000 2200"` means canvas is 3000 wide × 2200 tall
  - All coordinates are relative to this

#### 2. Definitions (`<defs>`)
```xml
<defs>
  <style type="text/css">
    .interactive-section { cursor: pointer; }
  </style>
</defs>
```
- Contains reusable elements (styles, gradients, patterns)
- Not visible by itself
- Applied to elements that reference them

#### 3. Groups (`<g>`)
```xml
<g id="sections">
  <!-- Child elements -->
</g>
```
- **Purpose**: Group related elements together
- **Benefits**: 
  - Apply transformations to all children at once
  - Organize code logically
  - Target with JavaScript/CSS

#### 4. Paths (`<path>`)
```xml
<path d="M 100,500 L 400,500 L 400,700 L 100,700 Z"/>
```
- **`d` attribute**: Path definition (the shape)
- **Path Commands**:
  - `M x,y` = Move to (x, y)
  - `L x,y` = Line to (x, y)
  - `H x` = Horizontal line to x
  - `V y` = Vertical line to y
  - `Z` = Close path (back to start)
  - `C x1,y1 x2,y2 x,y` = Cubic Bezier curve

**Example Path Breakdown:**
```xml
d="M 100,500 L 400,500 L 400,700 L 100,700 Z"
```
1. `M 100,500` - Start at point (100, 500)
2. `L 400,500` - Draw line to (400, 500)
3. `L 400,700` - Draw line to (400, 700)
4. `L 100,700` - Draw line to (100, 700)
5. `Z` - Close path back to start
Result: A rectangle!

#### 5. Text (`<text>`)
```xml
<text x="250" y="610" font-size="24px">101</text>
```
- **`x, y`**: Position of text
- **`text-anchor`**: Alignment (start, middle, end)
- **`fill`**: Text color

---

## Required Attributes

### ⚠️ CRITICAL: These Attributes MUST Be Present

#### On Section Group `<g>`

```xml
<g class="interactive-section"     ← REQUIRED
   id="101-group"                   ← REQUIRED (unique)
   data-section-id="101">           ← REQUIRED (for cart/filter)
```

| Attribute | Required? | Purpose | Example |
|-----------|-----------|---------|---------|
| `class` | ✅ YES | JavaScript selection | `"interactive-section"` |
| `id` | ✅ YES | Unique identifier | `"101-group"` |
| `data-section-id` | ✅ YES | Cart/filter logic | `"101"` |

#### On Section Path `<path>`

```xml
<path class="section-path"              ← REQUIRED
      id="101-section"                  ← REQUIRED (unique)
      d="M 100,500 ..."                 ← REQUIRED (the shape)
      data-default-color="rgb(204,204,204)"  ← REQUIRED
      data-id="2742140"                 ← REQUIRED (backend ID)
      style="fill: rgb(204,204,204);">  ← REQUIRED
```

| Attribute | Required? | Purpose | Example |
|-----------|-----------|---------|---------|
| `class` | ✅ YES | CSS styling | `"section-path"` |
| `id` | ✅ YES | Unique identifier | `"101-section"` |
| `d` | ✅ YES | Path definition | `"M 100,500 L 400,500..."` |
| `data-default-color` | ✅ YES | Reset color | `"rgb(204, 204, 204)"` |
| `data-id` | ✅ YES | Backend identifier | `"2742140"` |
| `style` | ✅ YES | Visual appearance | `"fill: rgb(204,204,204);"` |

#### On Section Label `<text>`

```xml
<text class="section-label 101-label"  ← REQUIRED
      id="101-label"                    ← REQUIRED (unique)
      x="250"                           ← REQUIRED
      y="610"                           ← REQUIRED
      font-size="24px">                 ← RECOMMENDED
  101                                   ← REQUIRED (text content)
</text>
```

| Attribute | Required? | Purpose | Example |
|-----------|-----------|---------|---------|
| `class` | ✅ YES | CSS styling | `"section-label 101-label"` |
| `id` | ✅ YES | Unique identifier | `"101-label"` |
| `x` | ✅ YES | Horizontal position | `"250"` |
| `y` | ✅ YES | Vertical position | `"610"` |
| Text content | ✅ YES | Section name | `"101"` |

---

## JavaScript Implementation

### Step 1: Load SVG into Your Page

```html
<!-- Method 1: Inline SVG -->
<div id="venue-map-container">
  <!-- Paste SVG code here -->
</div>

<!-- Method 2: Load from file -->
<div id="venue-map-container"></div>
<script>
  fetch('/venue-maps/Madison_Square_Garden.txt')
    .then(response => response.text())
    .then(data => {
      // Extract SVG from file
      const svgMatch = data.match(/<svg[^>]*>[\s\S]*<\/svg>/);
      if (svgMatch) {
        document.getElementById('venue-map-container').innerHTML = svgMatch[0];
        initializeMap();
      }
    });
</script>
```

### Step 2: Initialize Interactive Sections

```javascript
function initializeMap() {
  // Get all interactive sections
  const sections = document.querySelectorAll('.interactive-section');
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id');
    const path = section.querySelector('.section-path');
    
    if (!path || sectionId === 'parent') return; // Skip parent group
    
    // Add click handler
    section.addEventListener('click', function(e) {
      e.stopPropagation();
      handleSectionClick(section);
    });
    
    // Add hover effects
    section.addEventListener('mouseenter', function() {
      handleSectionHover(section, true);
    });
    
    section.addEventListener('mouseleave', function() {
      handleSectionHover(section, false);
    });
  });
  
  console.log(`Initialized ${sections.length} interactive sections`);
}
```

### Step 3: Handle Section Clicks (Cart Functionality)

```javascript
// Store selected sections
let selectedSections = [];

function handleSectionClick(section) {
  const sectionId = section.getAttribute('data-section-id');
  const path = section.querySelector('.section-path');
  const dataId = path.getAttribute('data-id');
  
  // Check if already selected
  const index = selectedSections.findIndex(s => s.id === sectionId);
  
  if (index > -1) {
    // Deselect
    selectedSections.splice(index, 1);
    resetSectionColor(section);
    console.log(`Removed section ${sectionId} from cart`);
  } else {
    // Select
    selectedSections.push({
      id: sectionId,
      dataId: dataId,
      element: section
    });
    highlightSection(section);
    console.log(`Added section ${sectionId} to cart`);
  }
  
  // Update cart display
  updateCartDisplay();
}

function highlightSection(section) {
  const path = section.querySelector('.section-path');
  path.style.fill = 'rgb(20, 116, 225)'; // Selected color
}

function resetSectionColor(section) {
  const path = section.querySelector('.section-path');
  const defaultColor = path.getAttribute('data-default-color');
  path.style.fill = defaultColor;
}

function updateCartDisplay() {
  const cartElement = document.getElementById('cart-items');
  cartElement.innerHTML = selectedSections.map(section => `
    <div class="cart-item">
      <span>Section ${section.id}</span>
      <button onclick="removeFromCart('${section.id}')">Remove</button>
    </div>
  `).join('');
  
  document.getElementById('cart-count').textContent = selectedSections.length;
}

function removeFromCart(sectionId) {
  const section = selectedSections.find(s => s.id === sectionId);
  if (section) {
    handleSectionClick(section.element);
  }
}
```

### Step 4: Handle Hover Effects

```javascript
function handleSectionHover(section, isHovering) {
  const sectionId = section.getAttribute('data-section-id');
  const path = section.querySelector('.section-path');
  const label = section.querySelector('.section-label');
  
  // Don't change color if section is selected
  const isSelected = selectedSections.some(s => s.id === sectionId);
  
  if (isHovering) {
    // Show tooltip
    showTooltip(section, sectionId);
    
    // Highlight if not selected
    if (!isSelected) {
      path.style.fill = 'rgb(142, 190, 245)'; // Hover color
    }
    
    // Make label bold
    if (label) {
      label.style.fontWeight = 'bold';
    }
  } else {
    // Hide tooltip
    hideTooltip();
    
    // Reset color if not selected
    if (!isSelected) {
      const defaultColor = path.getAttribute('data-default-color');
      path.style.fill = defaultColor;
    }
    
    // Reset label
    if (label) {
      label.style.fontWeight = 'normal';
    }
  }
}

function showTooltip(section, sectionId) {
  const tooltip = document.getElementById('section-tooltip');
  const rect = section.getBoundingClientRect();
  
  tooltip.innerHTML = `
    <strong>Section ${sectionId}</strong><br>
    Click to add to cart
  `;
  
  tooltip.style.left = rect.left + rect.width / 2 + 'px';
  tooltip.style.top = rect.top - 10 + 'px';
  tooltip.style.display = 'block';
}

function hideTooltip() {
  document.getElementById('section-tooltip').style.display = 'none';
}
```

---

## Search/Filter Implementation

```javascript
function initializeSearch() {
  const searchInput = document.getElementById('section-search');
  
  searchInput.addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    filterSections(searchTerm);
  });
}

function filterSections(searchTerm) {
  const sections = document.querySelectorAll('.interactive-section');
  let matchCount = 0;
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id');
    const label = section.querySelector('.section-label');
    const labelText = label ? label.textContent.toLowerCase() : '';
    
    // Skip parent group
    if (sectionId === 'parent') return;
    
    // Check if matches search
    const matches = sectionId.toLowerCase().includes(searchTerm) || 
                   labelText.includes(searchTerm);
    
    if (searchTerm === '' || matches) {
      // Show section
      section.style.display = 'block';
      section.style.opacity = '1';
      matchCount++;
    } else {
      // Hide section
      section.style.opacity = '0.2';
    }
  });
  
  // Update results count
  document.getElementById('search-results').textContent = 
    `Found ${matchCount} sections`;
}

// Clear search
function clearSearch() {
  document.getElementById('section-search').value = '';
  filterSections('');
}
```

---

## CSS Styling

```css
/* Container */
#venue-map-container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  background: #f5f5f5;
  border: 1px solid #ddd;
  border-radius: 8px;
  overflow: hidden;
}

/* SVG */
svg {
  width: 100%;
  height: auto;
  display: block;
}

/* Interactive sections */
.interactive-section {
  cursor: pointer;
  transition: all 0.3s ease;
}

.interactive-section:hover {
  filter: brightness(1.1);
}

/* Section paths */
.section-path {
  transition: fill 0.3s ease, stroke 0.3s ease;
  stroke: rgb(102, 102, 102);
  stroke-width: 1px;
}

.section-path:hover {
  stroke: rgb(20, 116, 225);
  stroke-width: 2px;
}

/* Section labels */
.section-label {
  font-family: Arial, sans-serif;
  font-size: 12px;
  fill: #000;
  pointer-events: none; /* Don't block clicks */
  user-select: none;
  transition: font-weight 0.2s ease;
}

/* Tooltip */
#section-tooltip {
  position: fixed;
  background: rgba(0, 0, 0, 0.9);
  color: white;
  padding: 8px 12px;
  border-radius: 4px;
  font-size: 14px;
  pointer-events: none;
  transform: translate(-50%, -100%);
  z-index: 1000;
  display: none;
  white-space: nowrap;
}

#section-tooltip::after {
  content: '';
  position: absolute;
  bottom: -5px;
  left: 50%;
  transform: translateX(-50%);
  border: 5px solid transparent;
  border-top-color: rgba(0, 0, 0, 0.9);
}

/* Cart */
#cart-container {
  position: fixed;
  top: 20px;
  right: 20px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 16px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  max-width: 300px;
}

#cart-count {
  background: rgb(20, 116, 225);
  color: white;
  border-radius: 50%;
  padding: 4px 8px;
  font-size: 12px;
  font-weight: bold;
}

.cart-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid #eee;
}

.cart-item button {
  background: #dc3545;
  color: white;
  border: none;
  padding: 4px 8px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
}

.cart-item button:hover {
  background: #c82333;
}

/* Search */
#search-container {
  padding: 16px;
  background: white;
  border-bottom: 1px solid #ddd;
}

#section-search {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 14px;
}

#section-search:focus {
  outline: none;
  border-color: rgb(20, 116, 225);
}

#search-results {
  margin-top: 8px;
  font-size: 12px;
  color: #666;
}
```

---

## Color System

### Standard Section Colors

```javascript
const SECTION_COLORS = {
  // Default/Standard seating
  default: 'rgb(204, 204, 204)',      // Light gray
  
  // Premium sections
  premium: 'rgb(62, 149, 237)',       // Blue
  floor: 'rgb(101, 171, 242)',        // Light blue
  
  // General Admission
  ga: 'rgb(68, 185, 108)',            // Green
  
  // VIP/Special
  vip: 'rgb(222, 145, 43)',           // Orange
  boxes: 'rgb(222, 145, 43)',         // Orange
  suites: 'rgb(222, 145, 43)',        // Orange
  
  // Interactive states
  selected: 'rgb(20, 116, 225)',      // Dark blue
  hover: 'rgb(142, 190, 245)',        // Light blue
  disabled: 'rgb(180, 180, 180)'      // Gray
};
```

### Applying Colors by Section Type

```javascript
function applySectionColors() {
  const sections = document.querySelectorAll('.interactive-section');
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id').toLowerCase();
    const path = section.querySelector('.section-path');
    
    let color = SECTION_COLORS.default;
    
    // Determine color based on section ID
    if (sectionId.includes('vip') || sectionId.includes('box')) {
      color = SECTION_COLORS.vip;
    } else if (sectionId.includes('ga') || sectionId.includes('general')) {
      color = SECTION_COLORS.ga;
    } else if (sectionId.includes('floor') || sectionId.includes('pit')) {
      color = SECTION_COLORS.floor;
    } else if (sectionId.includes('suite')) {
      color = SECTION_COLORS.suites;
    } else if (sectionId.match(/^[123]\d{2}$/)) {
      // Premium numbered sections (100s, 200s, 300s)
      color = SECTION_COLORS.premium;
    }
    
    // Set color
    path.setAttribute('data-default-color', color);
    path.style.fill = color;
  });
}
```

---

## Complete Working Example

### HTML Structure

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Venue Seating Map</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  
  <!-- Search Bar -->
  <div id="search-container">
    <input type="text" 
           id="section-search" 
           placeholder="Search sections (e.g., 101, VIP, Floor)">
    <div id="search-results"></div>
  </div>
  
  <!-- Map Container -->
  <div id="venue-map-container">
    <!-- SVG will be loaded here -->
  </div>
  
  <!-- Tooltip -->
  <div id="section-tooltip"></div>
  
  <!-- Shopping Cart -->
  <div id="cart-container">
    <h3>
      Cart 
      <span id="cart-count">0</span>
    </h3>
    <div id="cart-items"></div>
    <button id="checkout-btn" onclick="checkout()">
      Checkout
    </button>
  </div>
  
  <script src="app.js"></script>
</body>
</html>
```

### Complete JavaScript (app.js)

```javascript
// Global state
let selectedSections = [];
let currentVenue = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  loadVenueMap('Madison_Square_Garden');
  initializeSearch();
});

// Load venue map
function loadVenueMap(venueName) {
  fetch(`/venue-maps/${venueName}.txt`)
    .then(response => response.text())
    .then(data => {
      // Extract SVG
      const svgMatch = data.match(/<svg[^>]*>[\s\S]*<\/svg>/);
      if (svgMatch) {
        document.getElementById('venue-map-container').innerHTML = svgMatch[0];
        currentVenue = venueName;
        initializeMap();
        applySectionColors();
      }
    })
    .catch(error => {
      console.error('Error loading map:', error);
      alert('Failed to load venue map');
    });
}

// Initialize map interactions
function initializeMap() {
  const sections = document.querySelectorAll('.interactive-section');
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id');
    
    if (sectionId === 'parent') return;
    
    // Click handler
    section.addEventListener('click', function(e) {
      e.stopPropagation();
      handleSectionClick(section);
    });
    
    // Hover handlers
    section.addEventListener('mouseenter', function() {
      handleSectionHover(section, true);
    });
    
    section.addEventListener('mouseleave', function() {
      handleSectionHover(section, false);
    });
  });
  
  console.log(`✓ Initialized ${sections.length} sections`);
}

// Handle section click
function handleSectionClick(section) {
  const sectionId = section.getAttribute('data-section-id');
  const path = section.querySelector('.section-path');
  const dataId = path.getAttribute('data-id');
  
  const index = selectedSections.findIndex(s => s.id === sectionId);
  
  if (index > -1) {
    // Remove from cart
    selectedSections.splice(index, 1);
    const defaultColor = path.getAttribute('data-default-color');
    path.style.fill = defaultColor;
  } else {
    // Add to cart
    selectedSections.push({
      id: sectionId,
      dataId: dataId,
      element: section,
      venue: currentVenue
    });
    path.style.fill = 'rgb(20, 116, 225)';
  }
  
  updateCartDisplay();
}

// Handle hover
function handleSectionHover(section, isHovering) {
  const sectionId = section.getAttribute('data-section-id');
  const path = section.querySelector('.section-path');
  const label = section.querySelector('.section-label');
  const isSelected = selectedSections.some(s => s.id === sectionId);
  
  if (isHovering) {
    showTooltip(section, sectionId);
    if (!isSelected) {
      path.style.fill = 'rgb(142, 190, 245)';
    }
    if (label) label.style.fontWeight = 'bold';
  } else {
    hideTooltip();
    if (!isSelected) {
      const defaultColor = path.getAttribute('data-default-color');
      path.style.fill = defaultColor;
    }
    if (label) label.style.fontWeight = 'normal';
  }
}

// Tooltip functions
function showTooltip(section, sectionId) {
  const tooltip = document.getElementById('section-tooltip');
  const rect = section.getBoundingClientRect();
  
  tooltip.innerHTML = `<strong>Section ${sectionId}</strong><br>Click to add to cart`;
  tooltip.style.left = rect.left + rect.width / 2 + 'px';
  tooltip.style.top = rect.top - 10 + window.scrollY + 'px';
  tooltip.style.display = 'block';
}

function hideTooltip() {
  document.getElementById('section-tooltip').style.display = 'none';
}

// Update cart display
function updateCartDisplay() {
  const cartItems = document.getElementById('cart-items');
  const cartCount = document.getElementById('cart-count');
  
  cartItems.innerHTML = selectedSections.map(section => `
    <div class="cart-item">
      <span>Section ${section.id}</span>
      <button onclick="removeFromCart('${section.id}')">×</button>
    </div>
  `).join('');
  
  cartCount.textContent = selectedSections.length;
}

// Remove from cart
function removeFromCart(sectionId) {
  const section = selectedSections.find(s => s.id === sectionId);
  if (section) {
    handleSectionClick(section.element);
  }
}

// Search functionality
function initializeSearch() {
  const searchInput = document.getElementById('section-search');
  searchInput.addEventListener('input', function(e) {
    filterSections(e.target.value.toLowerCase());
  });
}

function filterSections(searchTerm) {
  const sections = document.querySelectorAll('.interactive-section');
  let matchCount = 0;
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id');
    const label = section.querySelector('.section-label');
    const labelText = label ? label.textContent.toLowerCase() : '';
    
    if (sectionId === 'parent') return;
    
    const matches = searchTerm === '' || 
                   sectionId.toLowerCase().includes(searchTerm) ||
                   labelText.includes(searchTerm);
    
    section.style.opacity = matches ? '1' : '0.2';
    if (matches) matchCount++;
  });
  
  document.getElementById('search-results').textContent = 
    searchTerm ? `Found ${matchCount} sections` : '';
}

// Apply section colors
function applySectionColors() {
  const sections = document.querySelectorAll('.interactive-section');
  
  sections.forEach(section => {
    const sectionId = section.getAttribute('data-section-id').toLowerCase();
    const path = section.querySelector('.section-path');
    
    let color = 'rgb(204, 204, 204)'; // default
    
    if (sectionId.includes('vip') || sectionId.includes('box')) {
      color = 'rgb(222, 145, 43)';
    } else if (sectionId.includes('ga')) {
      color = 'rgb(68, 185, 108)';
    } else if (sectionId.includes('floor')) {
      color = 'rgb(101, 171, 242)';
    } else if (sectionId.match(/^[123]\d{2}$/)) {
      color = 'rgb(62, 149, 237)';
    }
    
    path.setAttribute('data-default-color', color);
    path.style.fill = color;
  });
}

// Checkout
function checkout() {
  if (selectedSections.length === 0) {
    alert('Your cart is empty!');
    return;
  }
  
  const sections = selectedSections.map(s => ({
    sectionId: s.id,
    dataId: s.dataId,
    venue: s.venue
  }));
  
  console.log('Checkout data:', sections);
  alert(`Proceeding to checkout with ${sections.length} section(s)`);
  
  // Send to backend
  // fetch('/api/checkout', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({ sections })
  // });
}
```

---

## Testing & Validation

### Validation Script

Run this in browser console after loading a map:

```javascript
function validateMap() {
  console.log('🔍 Validating SVG Map...\n');
  
  const sections = document.querySelectorAll('.interactive-section');
  const issues = [];
  const seenIds = new Set();
  const seenDataIds = new Set();
  
  console.log(`Found ${sections.length} sections to validate\n`);
  
  sections.forEach((section, index) => {
    const sectionId = section.getAttribute('data-section-id');
    
    // Check 1: data-section-id exists
    if (!sectionId) {
      issues.push(`❌ Section ${index}: Missing data-section-id`);
      return;
    }
    
    // Check 2: No duplicate section IDs
    if (seenIds.has(sectionId)) {
      issues.push(`❌ Duplicate section ID: ${sectionId}`);
    }
    seenIds.add(sectionId);
    
    // Check 3: Has path element
    const path = section.querySelector('.section-path');
    if (!path) {
      issues.push(`❌ Section ${sectionId}: Missing path element`);
      return;
    }
    
    // Check 4: Path has data-id
    const dataId = path.getAttribute('data-id');
    if (!dataId) {
      issues.push(`❌ Section ${sectionId}: Missing data-id`);
    } else if (seenDataIds.has(dataId)) {
      issues.push(`⚠️  Duplicate data-id: ${dataId}`);
    }
    seenDataIds.add(dataId);
    
    // Check 5: Valid color format
    const color = path.getAttribute('data-default-color');
    if (!color || !color.match(/rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)/)) {
      issues.push(`⚠️  Section ${sectionId}: Invalid color format`);
    }
    
    // Check 6: Has label
    const label = section.querySelector('.section-label');
    if (!label) {
      issues.push(`⚠️  Section ${sectionId}: Missing label`);
    }
  });
  
  // Print results
  console.log('═══════════════════════════════════════');
  if (issues.length === 0) {
    console.log('✅ VALIDATION PASSED!');
    console.log(`All ${sections.length} sections are valid`);
  } else {
    console.log('❌ VALIDATION FAILED!');
    console.log(`Found ${issues.length} issues:\n`);
    issues.forEach(issue => console.log(issue));
  }
  console.log('═══════════════════════════════════════');
  
  return issues.length === 0;
}

// Run validation
validateMap();
```

### Manual Testing Checklist

Test each map:

- [ ] Map loads without errors
- [ ] All sections are visible
- [ ] Clicking sections adds to cart
- [ ] Clicking again removes from cart
- [ ] Hover shows tooltip
- [ ] Hover changes section color
- [ ] Search finds correct sections
- [ ] Cart count updates correctly
- [ ] No console errors
- [ ] Labels are readable

---

## Common Issues & Solutions

### Issue 1: Sections Not Clickable

**Problem:** Clicking sections does nothing

**Solution:**
```javascript
// Check if event listeners are attached
const sections = document.querySelectorAll('.interactive-section');
console.log(`Found ${sections.length} sections`);

// Make sure initializeMap() was called
initializeMap();
```

### Issue 2: Wrong Section Selected

**Problem:** Clicking one section selects another

**Cause:** Duplicate `data-section-id` values

**Solution:**
```javascript
// Find duplicates
const ids = [];
document.querySelectorAll('.interactive-section').forEach(s => {
  const id = s.getAttribute('data-section-id');
  if (ids.includes(id)) {
    console.error(`Duplicate ID: ${id}`);
  }
  ids.push(id);
});
```

### Issue 3: Labels Not Showing

**Problem:** Section labels are missing

**Cause:** Missing `<text>` elements

**Solution:** All files in `fixed_maps/` already have labels added!

### Issue 4: Colors Not Working

**Problem:** Sections don't change color

**Cause:** Invalid RGB format

**Solution:**
```javascript
// Fix color format
const path = section.querySelector('.section-path');
path.setAttribute('data-default-color', 'rgb(204, 204, 204)');
path.style.fill = 'rgb(204, 204, 204)';
```

### Issue 5: Search Not Finding Sections

**Problem:** Search returns no results

**Cause:** Case sensitivity or missing labels

**Solution:**
```javascript
// Use case-insensitive search
const searchTerm = input.value.toLowerCase();
const sectionId = section.getAttribute('data-section-id').toLowerCase();
```

---

## Summary Checklist

Before deploying, verify:

✅ **Files**
- [ ] Using files from `fixed_maps/` directory
- [ ] All 124 venue files present
- [ ] fix_log.json reviewed

✅ **Code**
- [ ] SVG loads correctly
- [ ] Event listeners attached
- [ ] Cart functionality works
- [ ] Search/filter works
- [ ] Colors display correctly

✅ **Testing**
- [ ] Validation script passes
- [ ] Manual testing completed
- [ ] No console errors
- [ ] All sections clickable
- [ ] Labels visible

✅ **Performance**
- [ ] Maps load quickly
- [ ] No lag when clicking
- [ ] Smooth hover effects

---

## Need Help?

1. **Run validation script** - See Testing section
2. **Check fix_log.json** - See what was changed
3. **Review console errors** - Browser DevTools
4. **Test with simple map first** - Try 713_Music_Hall.txt (smallest)

---

**🎉 You're ready to build an amazing venue map application!**

All 124 maps are fixed, validated, and ready to use. Follow this guide step-by-step and you'll have a fully functional interactive seating map system.
